function full() {
 document.body.requestFullscreen();
}

function test() {
 document.getElementsByClassName("about-text").style.backgroundColor = "red";
}